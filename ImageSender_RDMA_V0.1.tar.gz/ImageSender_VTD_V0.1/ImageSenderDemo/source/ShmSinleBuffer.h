// ShmReader.cpp : Sample implementation of a process reading
// from a shared memory segment (double buffered) with RDB layout
// (c) 2016 by VIRES Simulationstechnologie GmbH
// Provided AS IS without any warranty!
//

#ifndef _SHM_HH
#define _SHM_HH

#include <stdlib.h>
#include <stdio.h>
#include <sys/shm.h>
#include <string.h>
#include <unistd.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <cstring>
#include <sstream>
#include "RDBHandler.h"
#include "viRDBIcd.h"

unsigned int mShmKey       = 0x8130;                            // key of the SHM segment
unsigned int mCheckMask    = RDB_SHM_BUFFER_FLAG_TC;
void*        mShmPtr       = 0;                                 // pointer to the SHM segment
size_t       mShmTotalSize = 0;                                 // remember the total size of the SHM segment
bool         mVerbose      = false;                             // run in verbose mode?
int          mForceBuffer  = -1;                                // force reading one of the SHM buffers (0=A, 1=B)

RDB_SHM_BUFFER_INFO_t* pCurrentBufferInfo = 0;



void openShm();

void* getImageData();

void setFlag(RDB_SHM_BUFFER_INFO_t* pCurrentBufferInfo);

/**
* open the shared memory segment
*/
void openShm()
{
    // do not open twice!
    if ( mShmPtr )
    {
        fprintf( stderr, "openShm was already called\n" );
        return;
    }

    int shmid = 0; 

    if ( ( shmid = shmget( mShmKey, 0, 0 ) ) < 0 )
    {
        fprintf( stderr, "No matching key %i != %ui \n", shmid, mShmKey);
        return;
    }
    else
    {
        fprintf( stderr, "Matching key %i\n", shmid);
    }

    if ( ( mShmPtr = (char *)shmat( shmid, (char *)0, 0 ) ) == (char *) -1 )
    {
        perror("openShm: shmat()");
        mShmPtr = 0;
    }

    if ( mShmPtr )
    {
        struct shmid_ds sInfo;

        if ( ( shmid = shmctl( shmid, IPC_STAT, &sInfo ) ) < 0 )
            perror( "openShm: shmctl()" );
        else
            mShmTotalSize = sInfo.shm_segsz;
    }
}

void* getImageData()
{
    if ( !mShmPtr )
        return 0;

    // get a pointer to the shm info block
    RDB_SHM_HDR_t* shmHdr = ( RDB_SHM_HDR_t* ) ( mShmPtr );

    if ( !shmHdr )
        return 0;

    //jincheng 2022.11.21 just read from buffer A

    // allocate space for the buffer infos
    RDB_SHM_BUFFER_INFO_t** pBufferInfo = ( RDB_SHM_BUFFER_INFO_t** ) ( new char [ shmHdr->noBuffers * sizeof( RDB_SHM_BUFFER_INFO_t* ) ] );

    char* dataPtr = ( char* ) shmHdr;
    dataPtr += shmHdr->headerSize;

    for ( int i = 0; i < shmHdr->noBuffers; i++ )
    {
        pBufferInfo[ i ] = ( RDB_SHM_BUFFER_INFO_t* ) dataPtr;
        dataPtr += pBufferInfo[ i ]->thisSize;
    }

    // get the pointers to message section in each buffer
    RDB_MSG_t* pRdbMsgA = ( RDB_MSG_t* ) ( ( ( char* ) mShmPtr ) + pBufferInfo[0]->offset );
    
    // pointer to the message that will actually be read
    RDB_MSG_t* pRdbMsg  = 0;

    // remember the flags that are set for each buffer
    unsigned int flagsA = pBufferInfo[ 0 ]->flags;
    

    bool readyForReadA = ( ( flagsA & mCheckMask ) || !mCheckMask ) && !( flagsA & RDB_SHM_BUFFER_FLAG_LOCK );
    
    
    pRdbMsg            = pRdbMsgA; 
    pCurrentBufferInfo = pBufferInfo[ 0 ];
    
    
    unsigned int maxReadSize = pCurrentBufferInfo->bufferSize;
    
    void* myImage = (char*) shmHdr + pCurrentBufferInfo->offset + 72;
    
    std::cout<<"Image pointer : "<<myImage<<std::endl;

    return myImage;
}

void setFlag(RDB_SHM_BUFFER_INFO_t* pCurrentBufferInfo)
{
    // release after reading
    pCurrentBufferInfo->flags &= ~mCheckMask;                   // remove the check mask
    pCurrentBufferInfo->flags &= ~RDB_SHM_BUFFER_FLAG_LOCK;     // remove the lock mask
}

#endif 
