// ShmReader.cpp : Sample implementation of a process reading
// from a shared memory segment (double buffered) with RDB layout
// (c) 2016 by VIRES Simulationstechnologie GmbH
// Provided AS IS without any warranty!
//

#ifndef _SHM_HH
#define _SHM_HH

#include <stdlib.h>
#include <stdio.h>
#include <sys/shm.h>
#include <string.h>
#include <unistd.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <cstring>
#include <sstream>
#include "RDBHandler.h"
#include "viRDBIcd.h"

unsigned int mShmKey       = 0x8130;                            // key of the SHM segment
unsigned int mCheckMask    = RDB_SHM_BUFFER_FLAG_TC;
void*        mShmPtr       = 0;                                 // pointer to the SHM segment
size_t       mShmTotalSize = 0;                                 // remember the total size of the SHM segment
bool         mVerbose      = false;                             // run in verbose mode?
int          mForceBuffer  = -1;                                // force reading one of the SHM buffers (0=A, 1=B)

RDB_SHM_BUFFER_INFO_t* pCurrentBufferInfo = 0;



void openShm();

void* checkShm();

void setFlag(RDB_SHM_BUFFER_INFO_t* pCurrentBufferInfo);

/**
* open the shared memory segment
*/
void openShm()
{
    // do not open twice!
    if ( mShmPtr )
    {
        fprintf( stderr, "openShm was already called\n" );
        return;
    }

    int shmid = 0; 

    if ( ( shmid = shmget( mShmKey, 0, 0 ) ) < 0 )
    {
        fprintf( stderr, "No matching key %i != %ui \n", shmid, mShmKey);
        return;
    }
    else
    {
        fprintf( stderr, "Matching key %i\n", shmid);
    }

    if ( ( mShmPtr = (char *)shmat( shmid, (char *)0, 0 ) ) == (char *) -1 )
    {
        perror("openShm: shmat()");
        mShmPtr = 0;
    }

    if ( mShmPtr )
    {
        struct shmid_ds sInfo;

        if ( ( shmid = shmctl( shmid, IPC_STAT, &sInfo ) ) < 0 )
            perror( "openShm: shmctl()" );
        else
            mShmTotalSize = sInfo.shm_segsz;
    }
}

void* checkShm()
{
    if ( !mShmPtr )
        return 0;

    // get a pointer to the shm info block
    RDB_SHM_HDR_t* shmHdr = ( RDB_SHM_HDR_t* ) ( mShmPtr );

    if ( !shmHdr )
        return 0;

    //jincheng 2022.11.21 just read from buffer A
    
    if ( ( shmHdr->noBuffers != 2 ) )
    {
        fprintf( stderr, "checkShm: no or wrong number of buffers in shared memory. I need two buffers!" );
        return 0;
    }
    
    
    //fprintf( stderr, "no of buffer = %d\n", shmHdr->noBuffers);
    
    std::cout<<"which buffer to read ... "<<std::endl;

    // allocate space for the buffer infos
    RDB_SHM_BUFFER_INFO_t** pBufferInfo = ( RDB_SHM_BUFFER_INFO_t** ) ( new char [ shmHdr->noBuffers * sizeof( RDB_SHM_BUFFER_INFO_t* ) ] );

    char* dataPtr = ( char* ) shmHdr;
    dataPtr += shmHdr->headerSize;

    for ( int i = 0; i < shmHdr->noBuffers; i++ )
    {
        pBufferInfo[ i ] = ( RDB_SHM_BUFFER_INFO_t* ) dataPtr;
        dataPtr += pBufferInfo[ i ]->thisSize;
    }

    // get the pointers to message section in each buffer
    RDB_MSG_t* pRdbMsgA = ( RDB_MSG_t* ) ( ( ( char* ) mShmPtr ) + pBufferInfo[0]->offset );
    
    RDB_MSG_t* pRdbMsgB = ( RDB_MSG_t* ) ( ( ( char* ) mShmPtr ) + pBufferInfo[1]->offset );
    
    std::cout<<"pRdbMsgB :"<<pRdbMsgB<<std::endl;
    
    std::cout<<"pBufferInfo[1]->offset: "<<pBufferInfo[1]->offset<<std::endl;
    
    std::cout<<"pBufferInfo[1]: "<<pBufferInfo[1]<<std::endl;
    
    // pointer to the message that will actually be read
    RDB_MSG_t* pRdbMsg  = 0;

    // remember the flags that are set for each buffer
    unsigned int flagsA = pBufferInfo[ 0 ]->flags;
    
    unsigned int flagsB = pBufferInfo[ 1 ]->flags;


    bool readyForReadA = ( ( flagsA & mCheckMask ) || !mCheckMask ) && !( flagsA & RDB_SHM_BUFFER_FLAG_LOCK );

    bool readyForReadB = ( ( flagsB & mCheckMask ) || !mCheckMask ) && !( flagsB & RDB_SHM_BUFFER_FLAG_LOCK );


    if ( mForceBuffer < 0 )  // auto-select the buffer if none is forced to be read
    {
        // check which buffer to read
        
    
        if ( ( readyForReadA ) && ( readyForReadB ) )
        {
            if ( pRdbMsgA->hdr.frameNo > pRdbMsgB->hdr.frameNo )        // force using the latest image!!
            {
                pRdbMsg            = pRdbMsgA; 
                pCurrentBufferInfo = pBufferInfo[ 0 ];
                std::cout<<"read from buffer A... "<<std::endl;
            }
            else
            {
                pRdbMsg            = pRdbMsgB; 
                pCurrentBufferInfo = pBufferInfo[ 1 ];
                std::cout<<"read from buffer B... "<<std::endl;
            }
        }
        else if ( readyForReadA )
        {
            pRdbMsg            = pRdbMsgA; 
            pCurrentBufferInfo = pBufferInfo[ 0 ];
            std::cout<<"read from buffer A... "<<std::endl;
        }
        else if ( readyForReadB )
        {
            pRdbMsg            = pRdbMsgB;
            pCurrentBufferInfo = pBufferInfo[ 1 ];
            std::cout<<"read from buffer B... "<<std::endl;
        }
    }
    
    else if ( ( mForceBuffer == 0 ) && readyForReadA )   // force reading buffer A
    {
        pRdbMsg            = pRdbMsgA; 
        pCurrentBufferInfo = pBufferInfo[ 0 ];
        std::cout<<"read from buffer A... "<<std::endl;
    }
    else if ( ( mForceBuffer == 1 ) && readyForReadB ) // force reading buffer B
    {
        pRdbMsg            = pRdbMsgB;
        pCurrentBufferInfo = pBufferInfo[ 1 ];
        std::cout<<"read from buffer B... "<<std::endl;
    }
    
    std::cout<<"22222222222222222 ... "<<std::endl;
    
    // lock the buffer that will be processed now (by this, no other process will alter the contents)
    if ( pCurrentBufferInfo )
        pCurrentBufferInfo->flags |= RDB_SHM_BUFFER_FLAG_LOCK;

    // no data available?
    if ( !pRdbMsg || !pCurrentBufferInfo )
    {
        delete pBufferInfo;
        std::cout<<" pBufferInfo "<<std::endl;
        pBufferInfo = 0;

        // return with valid result if simulation is not yet running
        if ( ( pRdbMsgA->hdr.frameNo == 0 ) ) //&& ( pRdbMsgB->hdr.frameNo == 0 ) )
            return NULL;

        // otherwise return a failure
        return 0;
    }
    std::cout<<"33333333333333333 ... "<<std::endl;

    // handle all messages in the buffer
    if ( !pRdbMsg->hdr.dataSize )
    {
        fprintf( stderr, "checkShm: zero message data size, error.\n" );
        return 0;
    }
    
    
    
    unsigned int maxReadSize = pCurrentBufferInfo->bufferSize;
    
    void* myImage = (char*) shmHdr + pCurrentBufferInfo->offset + 72;
    
    std::cout<<"Image pointer : "<<myImage<<std::endl;

    return myImage;
}

void setFlag(RDB_SHM_BUFFER_INFO_t* pCurrentBufferInfo)
{
    // release after reading
    pCurrentBufferInfo->flags &= ~mCheckMask;                   // remove the check mask
    pCurrentBufferInfo->flags &= ~RDB_SHM_BUFFER_FLAG_LOCK;     // remove the lock mask
}

#endif 
