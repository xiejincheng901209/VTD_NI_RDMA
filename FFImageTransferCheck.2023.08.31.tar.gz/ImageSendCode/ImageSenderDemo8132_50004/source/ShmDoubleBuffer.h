// ShmReader.cpp : Sample implementation of a process reading
// from a shared memory segment (double buffered) with RDB layout
// (c) 2016 by VIRES Simulationstechnologie GmbH
// Provided AS IS without any warranty!
//

#ifndef _SHM_HH
#define _SHM_HH

#include <stdlib.h>
#include <stdio.h>
#include <sys/shm.h>
#include <string.h>
#include <unistd.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <cstring>
#include <sstream>
#include "RDBHandler.h"
#include "viRDBIcd.h"

unsigned int    mShmKey         = 0x8132;                            // key of the SHM segment
unsigned int    mCheckMask      = RDB_SHM_BUFFER_FLAG_TC;
void*           mShmPtr         = 0;                                 // pointer to the SHM segment
size_t          mShmTotalSize   = 0;                                 // remember the total size of the SHM segment
bool            mVerbose        = false;                             // run in verbose mode?
int             mForceBuffer    = -1;                                // force reading one of the SHM buffers (0=A, 1=B)
int             lastFrameNum    = 0;
uint16_t        width           = 1920;                               // width of the image        @unit pixel
uint16_t        height          = 1080;                               // height of the image       @unit pixel
std::string     pixelFormat     = "RGB";
RDB_IMAGE_t*    myImagePro;

int countNum = 0;

RDB_SHM_BUFFER_INFO_t* pCurrentBufferInfo = 0;



void openShm();

void* getImageData();
void getImageProperties();
void handleMessage( RDB_MSG_t* msg );
void parseRDBMessageEntry( const double & simTime, const unsigned int & simFrame, RDB_MSG_ENTRY_HDR_t* entryHdr, int& counter);

/**
* open the shared memory segment
*/
void openShm()
{
    // do not open twice!
    if ( mShmPtr )
    {
        fprintf( stderr, "openShm was already called\n" );
        return;
    }

    std::cout<<"shmKey: "<<mShmKey<<std::endl;
    int shmid = 0; 

    if ( ( shmid = shmget( mShmKey, 0, 0 ) ) < 0 )
    {
        fprintf( stderr, "No matching key %i != %ui \n", shmid, mShmKey);
        return;
    }
    else
    {
        fprintf( stderr, "Matching key %i\n", shmid);
    }

    if ( ( mShmPtr = (char *)shmat( shmid, (char *)0, 0 ) ) == (char *) -1 )
    {
        perror("openShm: shmat()");
        mShmPtr = 0;
    }

    if ( mShmPtr )
    {
        struct shmid_ds sInfo;

        if ( ( shmid = shmctl( shmid, IPC_STAT, &sInfo ) ) < 0 )
            perror( "openShm: shmctl()" );
        else
            mShmTotalSize = sInfo.shm_segsz;
    }
}

void* getImageData()
{
    if ( !mShmPtr )
        return 0;

    // get a pointer to the shm info block
    RDB_SHM_HDR_t* shmHdr = ( RDB_SHM_HDR_t* ) ( mShmPtr );

    if ( !shmHdr )
        return 0;

    if ( ( shmHdr->noBuffers != 2 ) )
        {
            fprintf( stderr, "checkShm: no or wrong number of buffers in shared memory. I need two buffers!" );
            return 0;
        }
    //jincheng 2023.02.08 read from double buffer

    // allocate space for the buffer infos
    RDB_SHM_BUFFER_INFO_t** pBufferInfo = ( RDB_SHM_BUFFER_INFO_t** ) ( new char [ shmHdr->noBuffers * sizeof( RDB_SHM_BUFFER_INFO_t* ) ] );
    RDB_SHM_BUFFER_INFO_t*  pCurrentBufferInfo = 0;

    char* dataPtr = ( char* ) shmHdr;
    dataPtr += shmHdr->headerSize;

    for ( int i = 0; i < shmHdr->noBuffers; i++ )
    {
        pBufferInfo[ i ] = ( RDB_SHM_BUFFER_INFO_t* ) dataPtr;
        dataPtr += pBufferInfo[ i ]->thisSize;
    }

    // get the pointers to message section in each buffer
    RDB_MSG_t* pRdbMsgA = ( RDB_MSG_t* ) ( ( ( char* ) mShmPtr ) + pBufferInfo[0]->offset );
    RDB_MSG_t* pRdbMsgB = ( RDB_MSG_t* ) ( ( ( char* ) mShmPtr ) + pBufferInfo[1]->offset );
    
    // pointer to the message that will actually be read
    RDB_MSG_t* pRdbMsg  = 0;

    // remember the flags that are set for each buffer
    unsigned int flagsA = pBufferInfo[ 0 ]->flags;
    unsigned int flagsB = pBufferInfo[ 1 ]->flags;
    

    bool readyForReadA = ( ( flagsA & mCheckMask ) || !mCheckMask ) && !( flagsA & RDB_SHM_BUFFER_FLAG_LOCK );
    bool readyForReadB = ( ( flagsB & mCheckMask ) || !mCheckMask ) && !( flagsB & RDB_SHM_BUFFER_FLAG_LOCK );
    


    if ( mVerbose)
    {
        fprintf( stderr, "ImageReader::checkShm: before processing SHM\n" );
        fprintf( stderr, "ImageReader::checkShm: Buffer A: frameNo = %06d, flags = 0x%x, locked = <%s>, lock mask set = <%s>, readyForRead = <%s>\n", 
                         pRdbMsgA->hdr.frameNo, 
                         flagsA,
                         ( flagsA & RDB_SHM_BUFFER_FLAG_LOCK ) ? "true" : "false",
                         ( flagsA & mCheckMask ) ? "true" : "false",
                         readyForReadA ?  "true" : "false" );

        fprintf( stderr, "                       Buffer B: frameNo = %06d, flags = 0x%x, locked = <%s>, lock mask set = <%s>, readyForRead = <%s>\n", 
                         pRdbMsgB->hdr.frameNo, 
                         flagsB,
                         ( flagsB & RDB_SHM_BUFFER_FLAG_LOCK ) ? "true" : "false",
                         ( flagsB & mCheckMask ) ? "true" : "false",
                         readyForReadB ?  "true" : "false" );
    }



    if ( mForceBuffer < 0 )  // auto-select the buffer if none is forced to be read
    {
        // check which buffer to read
        if ( ( readyForReadA ) && ( readyForReadB ) )
        {
            if ( pRdbMsgA->hdr.frameNo >= pRdbMsgB->hdr.frameNo )        // force using the latest image!!
            {
                pRdbMsg            = pRdbMsgA; 
                pCurrentBufferInfo = pBufferInfo[ 0 ];
                //std::cout<<"Frame No   A > = B This time read from A..."<<std::endl;
            }
            else
            {
                pRdbMsg            = pRdbMsgB; 
                pCurrentBufferInfo = pBufferInfo[ 1 ];
                //std::cout<<"Frame No   A < B This time read from B..."<<std::endl;
            }
        }
        else if ( readyForReadA )
        {
            pRdbMsg            = pRdbMsgA; 
            pCurrentBufferInfo = pBufferInfo[ 0 ];
            //std::cout<<"Only A Ready     This time read from A..."<<std::endl;
        }
        else if ( readyForReadB )
        {
            pRdbMsg            = pRdbMsgB;
            pCurrentBufferInfo = pBufferInfo[ 1 ];
            //std::cout<<"Only B Ready     This time read from B..."<<std::endl;
        }
    }
    else if ( ( mForceBuffer == 0 ) && readyForReadA )   // force reading buffer A
    {
        pRdbMsg            = pRdbMsgA; 
        pCurrentBufferInfo = pBufferInfo[ 0 ];
    }
    else if ( ( mForceBuffer == 1 ) && readyForReadB ) // force reading buffer B
    {
        pRdbMsg            = pRdbMsgB;
        pCurrentBufferInfo = pBufferInfo[ 1 ];
    }
    

    //jincheng 2023.02.08 if no effective pointer get then return...

    if(!pRdbMsg)
    {
        return 0;
    }

    // lock the buffer that will be processed now (by this, no other process will alter the contents)
    if ( pCurrentBufferInfo )
        pCurrentBufferInfo->flags |= RDB_SHM_BUFFER_FLAG_LOCK;


    if ( !pRdbMsg || !pCurrentBufferInfo )
    {
        delete pBufferInfo;
        pBufferInfo = 0;

        // return with valid result if simulation is not yet running
        if ( ( pRdbMsgA->hdr.frameNo == 0 ) && ( pRdbMsgB->hdr.frameNo == 0 ) )
            return 0;

        // otherwise return a failure
        return 0;
    }
    
    //jincheng 2023.02.08 FrameNum judge and make sure get effective pointer...
    if(pRdbMsg->hdr.frameNo - lastFrameNum != 1 )
        {
            std::cout<<std::endl<<"************************Warning Frame Num wrong*************************************"<<std::endl<<std::endl<<std::endl<<std::endl;
            /* pCurrentBufferInfo->flags &= ~mCheckMask;                   // remove the check mask
            pCurrentBufferInfo->flags &= ~RDB_SHM_BUFFER_FLAG_LOCK;     // remove the lock mask
            
            return 0; */
        }

    //jincheng 2023.02.08 FrameNum judge...
    if(pRdbMsg->hdr.frameNo - lastFrameNum == 0)
        {
            std::cout<<std::endl<<"Warning Frame Repeat**************************************************************"<<std::endl<<std::endl<<std::endl<<std::endl;
            pCurrentBufferInfo->flags &= ~mCheckMask;                   // remove the check mask
            pCurrentBufferInfo->flags &= ~RDB_SHM_BUFFER_FLAG_LOCK;     // remove the lock mask
            return 0;
        }
    
    lastFrameNum = pRdbMsg->hdr.frameNo;
    

    //jincheng 2023.02.08 get image data pointer....
    void* myImage = (char*) shmHdr + pCurrentBufferInfo->offset + 72;


    // release after reading
    pCurrentBufferInfo->flags &= ~mCheckMask;                   // remove the check mask
    pCurrentBufferInfo->flags &= ~RDB_SHM_BUFFER_FLAG_LOCK;     // remove the lock mask


    if ( mVerbose )
    {
        unsigned int flagsA = pBufferInfo[ 0 ]->flags;
        unsigned int flagsB = pBufferInfo[ 1 ]->flags;

        fprintf( stderr, "ImageReader::checkShm: after processing SHM\n" );
        fprintf( stderr, "ImageReader::checkShm: Buffer A: frameNo = %06d, flags = 0x%x, locked = <%s>, lock mask set = <%s>\n", 
                         pRdbMsgA->hdr.frameNo, 
                         flagsA,
                         ( flagsA & RDB_SHM_BUFFER_FLAG_LOCK ) ? "true" : "false",
                         ( flagsA & mCheckMask ) ? "true" : "false" );
        fprintf( stderr, "                       Buffer B: frameNo = %06d, flags = 0x%x, locked = <%s>, lock mask set = <%s>.\n", 
                         pRdbMsgB->hdr.frameNo, 
                         flagsB,
                         ( flagsB & RDB_SHM_BUFFER_FLAG_LOCK ) ? "true" : "false",
                         ( flagsB & mCheckMask ) ? "true" : "false" );
    }




    
    std::cout<<"Frame Num : "<<pRdbMsg->hdr.frameNo<<std::endl;
    std::cout<<"Image pointer : "<<myImage<<std::endl;

    countNum += 1;

    return myImage;
}


void getImageProperties()
{
    if ( !mShmPtr )
        return ;

    // get a pointer to the shm info block
    RDB_SHM_HDR_t* shmHdr = ( RDB_SHM_HDR_t* ) ( mShmPtr );

    if ( !shmHdr )
        return ;

    //jincheng 2023.02.08 just get image properties from one buffer...

    // allocate space for the buffer infos
    RDB_SHM_BUFFER_INFO_t** pBufferInfo = ( RDB_SHM_BUFFER_INFO_t** ) ( new char [ shmHdr->noBuffers * sizeof( RDB_SHM_BUFFER_INFO_t* ) ] );

    char* dataPtr = ( char* ) shmHdr;
    dataPtr += shmHdr->headerSize;

    for ( int i = 0; i < shmHdr->noBuffers; i++ )
    {
        pBufferInfo[ i ] = ( RDB_SHM_BUFFER_INFO_t* ) dataPtr;
        dataPtr += pBufferInfo[ i ]->thisSize;
    }

    // get the pointers to message section in each buffer
    RDB_MSG_t* pRdbMsgA = ( RDB_MSG_t* ) ( ( ( char* ) mShmPtr ) + pBufferInfo[0]->offset );
    
    // pointer to the message that will actually be read
    RDB_MSG_t* pRdbMsg  = 0;

    // remember the flags that are set for each buffer
    unsigned int flagsA = pBufferInfo[ 0 ]->flags;

    bool readyForReadA = ( ( flagsA & mCheckMask ) || !mCheckMask ) && !( flagsA & RDB_SHM_BUFFER_FLAG_LOCK );
    
    pRdbMsg            = pRdbMsgA; 
    pCurrentBufferInfo = pBufferInfo[ 0 ];

    handleMessage( pRdbMsg );

    return ;

}

void handleMessage( RDB_MSG_t* msg )
{
    if ( !msg )
      return;

    if ( !msg->hdr.dataSize )
        return;

    RDB_MSG_ENTRY_HDR_t* entry = ( RDB_MSG_ENTRY_HDR_t* ) ( ( ( char* ) msg ) + msg->hdr.headerSize );
    uint32_t remainingBytes    = msg->hdr.dataSize;

    int msgCounter = 1;
    while ( remainingBytes )
    {
        parseRDBMessageEntry( msg->hdr.simTime, msg->hdr.frameNo, entry, msgCounter);

        remainingBytes -= ( entry->headerSize + entry->dataSize );

        if ( remainingBytes )
          entry = ( RDB_MSG_ENTRY_HDR_t* ) ( ( ( ( char* ) entry ) + entry->headerSize + entry->dataSize ) );
    }
}

void parseRDBMessageEntry( const double & simTime, const unsigned int & simFrame, RDB_MSG_ENTRY_HDR_t* entryHdr, int& counter)
{
    if (!entryHdr)
        return;

    int noElements = entryHdr->elementSize ? ( entryHdr->dataSize / entryHdr->elementSize ) : 0;
    //fprintf(stderr, "Packages found %i \n", noElements);

    char* dataPtr = (char*) entryHdr;

    dataPtr += entryHdr->headerSize;

    while (noElements--)      // only two types of messages are handled here
    {     
        switch (entryHdr->pkgId)
        {
            case RDB_PKG_ID_IMAGE:
                myImagePro = (RDB_IMAGE_t*) dataPtr;
                width = myImagePro->width;
                height = myImagePro->height;
                break;
            default:
                break;
        }

        dataPtr += entryHdr->elementSize;
     }
}


#endif 
