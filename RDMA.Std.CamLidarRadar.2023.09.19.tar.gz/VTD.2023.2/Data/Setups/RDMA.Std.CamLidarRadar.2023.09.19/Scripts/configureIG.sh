#!/bin/bash
#--------------------------------------------------
#
#   IG configuration routine
#
#--------------------------------------------------

cfgDir=../Config/ImageGenerator

filename=$1

#new, see ticket #4445: remove old configuration file first
rm -f $cfgDir/AutoCfgDatabase.xml 

echo -e "configureIG: database=<$filename>"

echo  '<IGconfig>\n'\
      '  <Database>\n'\
      '    <Entity attachToScene="1" ID="Terrain" filename="'$filename'" />\n'\
      '  </Database>\n'\
      '</IGconfig>' > $cfgDir/AutoCfgDatabase.xml

#new, see ticket #4445: change permissions
chmod a+rw $cfgDir/AutoCfgDatabase.xml 

echo -e "configureIG: done "
