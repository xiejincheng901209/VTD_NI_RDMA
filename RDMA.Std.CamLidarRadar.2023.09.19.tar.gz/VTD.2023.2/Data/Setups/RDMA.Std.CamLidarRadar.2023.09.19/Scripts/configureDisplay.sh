#!/bin/bash
#--------------------------------------------------
#
#   IG display configuration routine
#
#--------------------------------------------------

# set fallback for display and screen
dispNum=0
screenNum=0

# now try to extract display and screen number from environment variable
if [ ! -z $DISPLAY ] ; then
  set -f
  #echo "DISPLAY is ${DISPLAY}"
  
  mDisplay=(${DISPLAY#*:})
    
  if [ $#mDisplay != 0 ]; then

    #echo "mDisplay[0] xxx${mDisplay[0]}xxx"

    mDispScreen=(${mDisplay[0]//./ })
    
    #echo "mDispScreen[0] xxx${mDispScreen[0]}xxx"
    #echo "mDispScreen[1] xxx${mDispScreen[1]}xxx"
    #echo "numDispScreen is ${#mDispScreen}"

    # is display AND screen set or only display?
    if [ ${#mDispScreen} != 0 ]; then
        dispNum=${mDispScreen[0]}
        if [ ! -z ${mDispScreen[1]} ]; then
            screenNum=${mDispScreen[1]}
        fi
    fi
  fi
fi

#echo dispNum is $dispNum
#echo screenNum is $screenNum

vigDir=../Config/ImageGenerator
tgtFile=$vigDir/AutoCfgDisplay.xml

mWidth=$1
mHeight=$2
mPosX=$3
mPosY=$4
mBorder=$5
mScreen=$6
mVisual=$7
mViewportLeft=$8
mViewportRight=$9
mViewportBottom=$10
mViewportTop=$11

if [ "$mBorder" == "off" ]; then
    mBorder=0
else
    mBorder=1
fi

echo -e '<IGconfig>\n'\
      '  <SystemConfig>\n'\
      '    <Graphics smallFeatureCullPixelSize="3.9" lodscale="0.9" gamma="1 1 1" enableCursor="1" enableDatabasePagerThread="0" drawThreadCPUAffinity="1" appCullThreadCPUAffinity="0" enableTransparencyAntialiasing="1" enableMultisampling="1" targetFramerate="-1" schedulerStabilization="1" makeTexturesOptixCompatible="0" graphicsResourceUpload="0" configurationProfile="RAYTRACING" isLocalLightingSupportEnabled="0"  threadingModel="SingleThreaded" >\n'\
      '      <RenderSurface name="mainRS" x="'${mPosX}'" y="'${mPosY}'" width="'${mWidth}'" height="'${mHeight}'" depthBits="24" sampleBuffers="0" samples="0" borderVisible="'${mBorder}'" overrideRedirect="0" screenNum="'${screenNum}'"/>\n'\
      '      <Camera name="cam1" renderSurface="mainRS" viewPortX="0" viewPortY="0" viewPortWidth="'${mWidth}'" viewPortHeight="'${mHeight}'">\n'\
      '        <SymmetricPerspectiveAngles  fovX="60.00" fovY="35.983" near="1" far="1500" offsetHPR="0 0 0" offsetXYZ="0 0.0 0"/>\n'\
      '      </Camera>\n'\
      '    </Graphics>\n'\
      '  </SystemConfig>\n'\
      '</IGconfig>\n'\
      '\n'  > ${tgtFile}
